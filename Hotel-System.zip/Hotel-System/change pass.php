?php
session_start();
?> 
<?php include("connect1.php");
  $cname=$_SESSION["log_id"];
  $sql=mysqli_query($conn,"SELECT * FROM cust_login where cust_emailid='$cus_email'");
  $display=mysqli_fetch_array($sql);
?>
<?php
if(isset($_POST["btnsubmit"]))
{
  $capassword=$_POST['pd'];
  if($passwordd==$capassword)
  {
      $cpassword=$_POST['npd'];
      $sql=mysqli_query($conn,"UPDATE cust_login SET cust_pass= '$pass' WHERE cust_emailid='$cus_email");
      if($sql)
      {
          echo "<script>alert('Password Updated Succesfully!!Plase login again!!');window.location='../login/conntractorlogin.php'</script>";
      }
  }
  else
    echo "<script>alert('Please enter current password correctlty!!');window.location='changepass.php'</script>";
}
?>
<!-- <!DOCTYPE html>
<head>
<title>change password</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Visitors Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
<script src="js/jquery2.0.3.min.js"></script>
</head>
<body>
        </li>
        <!-- user login dropdown end -->
       
    </ul>
    <!--search & user info end-->
</div>
</header>
<!--header end-->
<!--sidebar start-->
<aside>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->
<!--main content start-->

<!-- <section id="main-content">
  <section class="wrapper">
  <div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <!-- <div class="row">
            <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading" align="center">
                            CHANGE PASSWORD
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form"  method="post">
                                    <div class="form-group">
                                        <label for="pd">Old Password</label>
                                        <input type="password" class="form-control" name="pd"  id="name">
                                    </div>
                                    <div class="form-group">
                                        <label for="npd">New Password</label>
                                        <input type="password" class="form-control" name="npd"  id="name">
                                    </div>
                               
                                <button type="submit" name="btnsubmit"class="btn btn-info">Submit</button>
                            </form>
                            </div>

                        </div>
                    </section>

            </div>
            <div class="col-lg-12">
               
            </div>
        </div>
        <div class="row">
            
        </div> -->
    <!DOCTYPE html>
<html lang="en">
  <head>
    <style>
        * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  background-size: cover;
  /* background-image:url('1.jpg'); */
  font-family: sans-serif;
}
.login-wrapper {
  height: 100vh;
  width: 100vw;
  display: flex;
  justify-content: center;
  align-items: center;
}
.form {
  position: relative;
  width: 100%;
  max-width: 380px;
  padding: 80px 40px 40px;
  background: rgba(0, 0, 0, 0.7);
  border-radius: 10px;
  color: #fff;
}
.form::before {
  content: "";
  position: absolute;
  top: 0;
  left: 0;
  width: 50%;
  height: 100%;
  background: rgba(255, 255, 255, 0.08);
  transform-origin: bottom left;
  border-radius: 10px;
  pointer-events: none;
}
.form img {
  position: absolute;
  top: -50px;
  left: calc(50% - 50px);
  width: 100px;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 50%;
}
.form h6
{
    color:white;
}
.form h2 {
  text-align: center;
  letter-spacing: 1px;
  
}
.form .input-group {
  position: relative;
}
.form .input-group input {
  width: 100%;
  padding: 10px 0;
  font-size: 1rem;
  letter-spacing: 1px;
  margin-bottom: 30px;
  border: none;
  border-bottom: 1px solid #fff;
  outline: none;
  background-color: transparent;
  color: inherit;
}
.form .input-group label {
  position: absolute;
  top: 0;
  left: 0;
  padding: 10px 0;
  font-size: 1rem;
  pointer-events: none;
  transition: 0.3s ease-out;
}
.form .input-group input:focus + label,
.form .input-group input:valid + label {
  transform: translateY(-18px);
  color: white;
  font-size: 0.8rem;
}
.submit-btn {
  display: block;
  margin-left: auto;
  border: none;
  outline: none;
  background: #ff652f;
  font-size: 1rem;
  text-transform: uppercase;
  letter-spacing: 1px;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
}
.forgot-pw {
  color: inherit;
}

#forgot-pw {
  position: absolute;
  display: flex;
  justify-content: center;
  align-items: center;
  top: 0;
  left: 0;
  right: 0;
  height: 0;
  z-index: 1;
  background: #fff;
  opacity: 0;
  transition: 0.6s;
}
#forgot-pw:target {
  height: 100%;
  opacity: 1;
}
.close {
  position: absolute;
  right: 1.5rem;
  top: 0.5rem;
  font-size: 2rem;
  font-weight: 900;
  text-decoration: none;
  color: inherit;
}
placeholder
{
    color:white;
}
        </style>
        <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" href="style.css" />
    <title>Login Form Demo</title>
  </head>
  <body>
    <div class="login-wrapper">
      <form action="" class="form" method="post">
        <h2>Login</h2>
        <h6>Old Password</h6>
        <div class="input-group">
          <input type="password" class="form-control" name="p_d"  id="name">
        </div>
        <h6>New Password</h6>
        <div class="input-group">
            
           <input type="password" class="form-control" name="npd"  id="name">
         
        </div>
        <button type="submit" name="btnsubmit"class="btn btn-info">Submit</button>
      </form>
    </div>
  </body>
</html>