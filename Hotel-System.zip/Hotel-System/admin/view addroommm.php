

<?php
 include_once('admin_connect.php');
$query = "select * from tbl_addrooms";
$result = mysqli_query($conn,$query);

?>





<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 60%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 19px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>


<body>
<tittle><center><h3>View Room Details</center></h3></tittle>
 
<center>

   <table border='1'> 
  <tr>
    <t>
    <th style="width:15px";>Room ID</th>
    <th style="width:15px";>Room Type</th>
    <th style="width:15px";>Room Block</th>
    <th style="width:15px";>Room Number</th>
    <th style="width:15px";>Choose Room</th>
    <th style="width:15px";>MultipleData</th>
    <th style="width:15px">price</th>
    <th style="width:15px">Action</th>
<t>

<?php
    while($rows=mysqli_fetch_assoc($result))
 {
   ?>
    <tr>
      <td><?php echo $rows['addroom_id']; ?></td>
      <td><?php echo $rows['room_type'] ; ?></td>
      <td><?php echo $rows['room_block']; ?></td>
      <td><?php echo $rows['room_number']; ?></td>
      <td><?php echo $rows['choose_room']; ?></td>
      <td><?php echo $rows['multipleData']; ?></td>
      <td><?php echo $rows['price']; ?></td>
 </tr>
 <?php
 }
 ?>
 
</table>
</center>
</body>

</html>